import React from 'react'

export default function HeaderFunc() {

  return (
    <div className='w-25 card'>
        <img src='https://picsum.photos/200' alt='...' />
        <div className='card-body'>
            <p>Tên sản phẩm</p>
            <p>1000</p>
        </div>
    </div>
  )
}
