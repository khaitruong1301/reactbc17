import React, { Component } from 'react'

export default class HeaderComponent extends Component {
  render() {
    return (
      <div className='text-center bg-primary p-5 text-white'>HeaderComponent</div>
    )
  }
}
