import React, { Component } from 'react'

export default class FooterComponent extends Component {
  render() {
    return (
      <div className='bg-warning text-white text-center p-5'>FooterComponent</div>
    )
  }
}
