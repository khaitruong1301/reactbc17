import React, { Component } from 'react'

export default class ContentComponent extends Component {
  render() {
    return (
      <div className='bg-success p-5'>ContentComponent</div>
    )
  }
}
